-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 02, 2018 at 10:02 AM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.1.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `restaurant`
--

-- --------------------------------------------------------

--
-- Table structure for table `availableitem`
--

CREATE TABLE `availableitem` (
  `id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `availableitem`
--

INSERT INTO `availableitem` (`id`, `item_id`, `date`) VALUES
(446, 1, '2018-04-20'),
(450, 1, '2018-04-26'),
(477, 1, '2018-04-27'),
(505, 1, '2018-04-28'),
(533, 1, '2018-04-29'),
(561, 1, '2018-04-30'),
(589, 1, '2018-05-01'),
(444, 2, '2018-04-20'),
(448, 2, '2018-04-26'),
(475, 2, '2018-04-27'),
(503, 2, '2018-04-28'),
(531, 2, '2018-04-29'),
(559, 2, '2018-04-30'),
(587, 2, '2018-05-01'),
(445, 3, '2018-04-20'),
(449, 3, '2018-04-26'),
(476, 3, '2018-04-27'),
(504, 3, '2018-04-28'),
(532, 3, '2018-04-29'),
(560, 3, '2018-04-30'),
(588, 3, '2018-05-01'),
(447, 4, '2018-04-20'),
(451, 4, '2018-04-26'),
(478, 4, '2018-04-27'),
(506, 4, '2018-04-28'),
(534, 4, '2018-04-29'),
(562, 4, '2018-04-30'),
(590, 4, '2018-05-01'),
(462, 6, '2018-04-26'),
(490, 6, '2018-04-27'),
(518, 6, '2018-04-28'),
(546, 6, '2018-04-29'),
(574, 6, '2018-04-30'),
(602, 6, '2018-05-01'),
(463, 7, '2018-04-26'),
(491, 7, '2018-04-27'),
(519, 7, '2018-04-28'),
(547, 7, '2018-04-29'),
(575, 7, '2018-04-30'),
(603, 7, '2018-05-01'),
(464, 8, '2018-04-26'),
(492, 8, '2018-04-27'),
(520, 8, '2018-04-28'),
(548, 8, '2018-04-29'),
(576, 8, '2018-04-30'),
(604, 8, '2018-05-01'),
(465, 9, '2018-04-26'),
(493, 9, '2018-04-27'),
(521, 9, '2018-04-28'),
(549, 9, '2018-04-29'),
(577, 9, '2018-04-30'),
(605, 9, '2018-05-01'),
(459, 10, '2018-04-26'),
(486, 10, '2018-04-27'),
(514, 10, '2018-04-28'),
(542, 10, '2018-04-29'),
(570, 10, '2018-04-30'),
(598, 10, '2018-05-01'),
(460, 11, '2018-04-26'),
(487, 11, '2018-04-27'),
(515, 11, '2018-04-28'),
(543, 11, '2018-04-29'),
(571, 11, '2018-04-30'),
(599, 11, '2018-05-01'),
(466, 12, '2018-04-26'),
(494, 12, '2018-04-27'),
(522, 12, '2018-04-28'),
(550, 12, '2018-04-29'),
(578, 12, '2018-04-30'),
(606, 12, '2018-05-01'),
(488, 13, '2018-04-27'),
(516, 13, '2018-04-28'),
(544, 13, '2018-04-29'),
(572, 13, '2018-04-30'),
(600, 13, '2018-05-01'),
(469, 15, '2018-04-26'),
(497, 15, '2018-04-27'),
(525, 15, '2018-04-28'),
(553, 15, '2018-04-29'),
(581, 15, '2018-04-30'),
(609, 15, '2018-05-01'),
(474, 16, '2018-04-26'),
(502, 16, '2018-04-27'),
(530, 16, '2018-04-28'),
(558, 16, '2018-04-29'),
(586, 16, '2018-04-30'),
(614, 16, '2018-05-01'),
(473, 17, '2018-04-26'),
(501, 17, '2018-04-27'),
(529, 17, '2018-04-28'),
(557, 17, '2018-04-29'),
(585, 17, '2018-04-30'),
(613, 17, '2018-05-01'),
(472, 18, '2018-04-26'),
(500, 18, '2018-04-27'),
(528, 18, '2018-04-28'),
(556, 18, '2018-04-29'),
(584, 18, '2018-04-30'),
(612, 18, '2018-05-01'),
(471, 19, '2018-04-26'),
(499, 19, '2018-04-27'),
(527, 19, '2018-04-28'),
(555, 19, '2018-04-29'),
(583, 19, '2018-04-30'),
(611, 19, '2018-05-01'),
(470, 20, '2018-04-26'),
(498, 20, '2018-04-27'),
(526, 20, '2018-04-28'),
(554, 20, '2018-04-29'),
(582, 20, '2018-04-30'),
(610, 20, '2018-05-01'),
(453, 21, '2018-04-26'),
(480, 21, '2018-04-27'),
(508, 21, '2018-04-28'),
(536, 21, '2018-04-29'),
(564, 21, '2018-04-30'),
(592, 21, '2018-05-01'),
(452, 22, '2018-04-26'),
(479, 22, '2018-04-27'),
(507, 22, '2018-04-28'),
(535, 22, '2018-04-29'),
(563, 22, '2018-04-30'),
(591, 22, '2018-05-01'),
(456, 23, '2018-04-26'),
(483, 23, '2018-04-27'),
(511, 23, '2018-04-28'),
(539, 23, '2018-04-29'),
(567, 23, '2018-04-30'),
(595, 23, '2018-05-01'),
(455, 24, '2018-04-26'),
(482, 24, '2018-04-27'),
(510, 24, '2018-04-28'),
(538, 24, '2018-04-29'),
(566, 24, '2018-04-30'),
(594, 24, '2018-05-01'),
(468, 25, '2018-04-26'),
(496, 25, '2018-04-27'),
(524, 25, '2018-04-28'),
(552, 25, '2018-04-29'),
(580, 25, '2018-04-30'),
(608, 25, '2018-05-01'),
(467, 26, '2018-04-26'),
(495, 26, '2018-04-27'),
(523, 26, '2018-04-28'),
(551, 26, '2018-04-29'),
(579, 26, '2018-04-30'),
(607, 26, '2018-05-01'),
(458, 27, '2018-04-26'),
(485, 27, '2018-04-27'),
(513, 27, '2018-04-28'),
(541, 27, '2018-04-29'),
(569, 27, '2018-04-30'),
(597, 27, '2018-05-01'),
(457, 28, '2018-04-26'),
(484, 28, '2018-04-27'),
(512, 28, '2018-04-28'),
(540, 28, '2018-04-29'),
(568, 28, '2018-04-30'),
(596, 28, '2018-05-01'),
(461, 29, '2018-04-26'),
(489, 29, '2018-04-27'),
(517, 29, '2018-04-28'),
(545, 29, '2018-04-29'),
(573, 29, '2018-04-30'),
(601, 29, '2018-05-01'),
(454, 30, '2018-04-26'),
(481, 30, '2018-04-27'),
(509, 30, '2018-04-28'),
(537, 30, '2018-04-29'),
(565, 30, '2018-04-30'),
(593, 30, '2018-05-01');

-- --------------------------------------------------------

--
-- Table structure for table `discountitem`
--

CREATE TABLE `discountitem` (
  `id` int(11) NOT NULL,
  `percentage` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `discountitem`
--

INSERT INTO `discountitem` (`id`, `percentage`, `item_id`, `date`) VALUES
(1, 10, 6, '2018-04-26'),
(2, 20, 9, '2018-04-26'),
(3, 30, 19, '2018-04-26'),
(4, 50, 29, '2018-04-26'),
(5, 10, 2, '2018-04-27'),
(6, 25, 4, '2018-04-27'),
(7, 10, 27, '2018-04-27'),
(8, 30, 12, '2018-04-27'),
(10, 20, 30, '2018-04-27'),
(11, 30, 1, '2018-04-28'),
(12, 10, 30, '2018-04-28'),
(13, 20, 28, '2018-04-28'),
(14, 25, 6, '2018-04-28'),
(15, 40, 25, '2018-04-28'),
(16, 30, 18, '2018-04-28'),
(17, 25, 21, '2018-04-29'),
(18, 10, 23, '2018-04-29'),
(19, 20, 27, '2018-04-29'),
(20, 30, 13, '2018-04-29'),
(21, 60, 6, '2018-04-29'),
(22, 25, 8, '2018-04-29'),
(23, 20, 12, '2018-04-29'),
(24, 10, 25, '2018-04-29'),
(25, 20, 2, '2018-04-29'),
(26, 10, 3, '2018-04-29'),
(27, 10, 4, '2018-04-30'),
(28, 40, 30, '2018-04-30'),
(29, 25, 23, '2018-04-30'),
(30, 20, 27, '2018-04-30'),
(31, 5, 11, '2018-04-30'),
(32, 10, 29, '2018-04-30'),
(33, 30, 12, '2018-04-30'),
(34, 60, 20, '2018-04-30'),
(35, 30, 1, '2018-05-01'),
(36, 10, 22, '2018-05-01'),
(37, 10, 30, '2018-05-01'),
(38, 25, 28, '2018-05-01'),
(39, 10, 6, '2018-05-01'),
(40, 30, 8, '2018-05-01'),
(41, 15, 26, '2018-05-01'),
(42, 10, 18, '2018-05-01');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(70) NOT NULL,
  `message` varchar(255) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `name`, `email`, `message`, `date`) VALUES
(1, 'MUNNA', 'jimunna150@gmail.com', 'This is the first testing', '2018-05-01');

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE `item` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `price` int(11) NOT NULL,
  `category` int(11) NOT NULL,
  `path` varchar(255) NOT NULL,
  `details` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`id`, `name`, `price`, `category`, `path`, `details`) VALUES
(1, 'Beef and Bacon Burger ', 380, 3, 'BeefAndBaconBurger.jpg', 'This gigantic beast has a massive 200mgm beef patty, smoky bbq sauce topped with beef bacon slice and shredded cheese to go'),
(2, 'BBQ beef burger ', 220, 3, 'BBQbeefBurger.jpg', 'single beef patty with bbq sauce'),
(3, 'BBQ chicken burger', 200, 3, 'BBQchickenburger.jpg', 'single chicken patty with bbq sauce'),
(4, 'Chicken burger with cheese', 130, 3, 'Chickenburger withcheese.jpg', 'exotic chicken patty'),
(6, 'Pasta BBQ', 325, 2, 'PastaBBQ.jpg', 'white sauce, tomato, chicken, cheese, garlic, mushroom, oregano'),
(7, 'Pasta Classico', 305, 2, 'PastaClassico.jpg', 'white sauce, tomato sauce, cheese, garlic, oregano'),
(8, 'Pasta Italiano', 280, 2, 'PastaItaliano.jpg', 'white sauce, beef, cheese, mushroom, garlic'),
(9, 'Pasta Vegetarian', 250, 2, 'PastaVegetarian.jpg', 'white sauce, red sauce, cheese, garlic mushroom, green chili, oregano, capsicum'),
(10, 'Lemonade', 100, 4, 'Lemonade.jpg', 'ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua'),
(11, 'Orange Juice', 120, 4, 'OrangeJuice.jpg', 'ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua'),
(12, 'Pineapple Juice', 130, 4, 'PineappleJuice.jpg', 'ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua'),
(13, 'Oreo Shake', 150, 4, 'OreoShake.jpg', 'ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua'),
(15, 'Sprite/Mirinda/coke (500ml)', 50, 4, 'spitecokemirinda.jpg', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec ultricies massa et erat luctus hendrerit. Curabitur non consequat enim.'),
(16, 'water', 15, 4, 'water.jpg', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec ultricies massa et erat luctus hendrerit. Curabitur non consequat enim.'),
(17, 'Veggie Supreme (Medium)', 540, 1, 'VeggieSupreme.jpg', 'onion, capsicum, mushroom, black olives, sweet corn'),
(18, 'Veggie Supreme ', 800, 1, 'VeggieSupreme.jpg', 'onion, capsicum, mushroom, black olives, sweet corn'),
(19, 'Veg Exotic (Medium)', 485, 1, 'VegExotic.jpg', 'Red capsicum, green capsicum, baby corn, black olives, jalapenos'),
(20, 'Veg Exotic (Large)', 785, 1, 'VegExotic.jpg', 'Red capsicum, green capsicum, baby corn, black olives, jalapenos'),
(21, 'Chicken Supreme (Medium)', 625, 1, 'ChickenSupreme.jpg', 'Aromatic Lebanese chicken, chicken tikka, schezwan chicken meatball'),
(22, 'Chicken Supreme (Large)', 900, 1, 'ChickenSupreme.jpg', 'Aromatic Lebanese chicken, chicken tikka, schezwan chicken meatball'),
(23, 'Country Feast (Medium)', 599, 1, 'CountryFeast.jpg', 'Onion, Capsicum, tomato, mushroom, chicken, beef'),
(24, 'Country Feast (Large)', 950, 1, 'CountryFeast.jpg', 'Onion, Capsicum, tomato, mushroom, chicken, beef'),
(25, 'Special Paneer (Medium)', 412, 1, 'SpecialPaneer.jpg', 'onion, special paneer, tomato, mushroom'),
(26, 'Special Paneer (Large)', 799, 1, 'SpecialPaneer.jpg', 'onion, special paneer, tomato, mushroom'),
(27, 'Four Season (Medium)', 485, 1, 'FourSeason.jpg', 'Chicken, beef, black olive, mushroom, capsicum'),
(28, 'Four Season (Large)', 795, 1, 'FourSeason.jpg', 'Chicken, beef, black olive, mushroom, capsicum'),
(29, 'Pasta Basta', 380, 2, 'PastaBasta.jpg', 'white sauce, tomato sauce, chicken garlic, tomato, mushroom, shrimp, green chili, beef, oregano'),
(30, 'Chocolate Cold coffee', 90, 4, 'Chocolate Cold coffee.jpg', 'ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua');

-- --------------------------------------------------------

--
-- Table structure for table `manager`
--

CREATE TABLE `manager` (
  `id` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `manager`
--

INSERT INTO `manager` (`id`, `username`, `password`) VALUES
(1, 'admin', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `orderfromtablenumber`
--

CREATE TABLE `orderfromtablenumber` (
  `id` int(11) NOT NULL,
  `tableNumber` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `adminNotice` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orderfromtablenumber`
--

INSERT INTO `orderfromtablenumber` (`id`, `tableNumber`, `user_id`, `date`, `adminNotice`) VALUES
(15, 1, 9, '2018-05-01', 1),
(16, 2, 9, '2018-05-01', 1);

-- --------------------------------------------------------

--
-- Table structure for table `orderlist`
--

CREATE TABLE `orderlist` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `date` date NOT NULL,
  `confirmOrder` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orderlist`
--

INSERT INTO `orderlist` (`id`, `user_id`, `item_id`, `price`, `quantity`, `date`, `confirmOrder`) VALUES
(52, 12, 4, 130, 1, '2018-05-01', 1),
(53, 9, 25, 412, 1, '2018-05-01', 1),
(54, 9, 3, 200, 2, '2018-05-01', 1),
(55, 9, 8, 196, 3, '2018-05-01', 1),
(56, 9, 18, 720, 1, '2018-05-01', 1),
(57, 9, 2, 220, 2, '2018-05-01', 1),
(58, 9, 6, 292, 2, '2018-05-01', 1),
(59, 9, 18, 720, 2, '2018-05-01', 1);

-- --------------------------------------------------------

--
-- Table structure for table `specialitem`
--

CREATE TABLE `specialitem` (
  `id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `specialitem`
--

INSERT INTO `specialitem` (`id`, `item_id`, `date`) VALUES
(5, 1, '2018-04-27'),
(12, 1, '2018-04-28'),
(10, 2, '2018-04-28'),
(29, 2, '2018-04-30'),
(11, 3, '2018-04-28'),
(30, 3, '2018-04-30'),
(37, 3, '2018-05-01'),
(38, 4, '2018-05-01'),
(1, 7, '2018-04-26'),
(18, 7, '2018-04-28'),
(19, 9, '2018-04-28'),
(14, 10, '2018-04-28'),
(15, 11, '2018-04-28'),
(23, 11, '2018-04-29'),
(34, 11, '2018-04-30'),
(42, 12, '2018-05-01'),
(16, 13, '2018-04-28'),
(26, 15, '2018-04-29'),
(28, 17, '2018-04-29'),
(44, 17, '2018-05-01'),
(9, 18, '2018-04-27'),
(20, 18, '2018-04-28'),
(2, 19, '2018-04-26'),
(27, 19, '2018-04-29'),
(6, 21, '2018-04-27'),
(31, 22, '2018-04-30'),
(40, 23, '2018-05-01'),
(39, 24, '2018-05-01'),
(8, 26, '2018-04-27'),
(25, 26, '2018-04-29'),
(36, 26, '2018-04-30'),
(43, 26, '2018-05-01'),
(7, 27, '2018-04-27'),
(22, 27, '2018-04-29'),
(41, 27, '2018-05-01'),
(3, 28, '2018-04-26'),
(21, 28, '2018-04-29'),
(33, 28, '2018-04-30'),
(4, 29, '2018-04-26'),
(17, 29, '2018-04-28'),
(24, 29, '2018-04-29'),
(35, 29, '2018-04-30'),
(13, 30, '2018-04-28'),
(32, 30, '2018-04-30');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `password` varchar(50) NOT NULL,
  `phonenumber` varchar(14) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `password`, `phonenumber`) VALUES
(8, 'jahid', '3d4f2bf07dc1be38b20cd6e46949a1071f9d0e3d', '+8801914951878'),
(9, 'jimunna', '3d4f2bf07dc1be38b20cd6e46949a1071f9d0e3d', '+8801914951878'),
(10, ' jimunna', '3d4f2bf07dc1be38b20cd6e46949a1071f9d0e3d', '+8801816138915'),
(11, ' mahamud', '9a3b10094e5fce55e7fe0239049a03fc4397225f', '+8801765000111'),
(12, 'testing', '7c4a8d09ca3762af61e59520943dc26494f8941b', '+8801675000111');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `availableitem`
--
ALTER TABLE `availableitem`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `item_id` (`item_id`,`date`);

--
-- Indexes for table `discountitem`
--
ALTER TABLE `discountitem`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `item_id` (`item_id`,`date`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `item`
--
ALTER TABLE `item`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `manager`
--
ALTER TABLE `manager`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `orderfromtablenumber`
--
ALTER TABLE `orderfromtablenumber`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `orderlist`
--
ALTER TABLE `orderlist`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `item_id` (`item_id`);

--
-- Indexes for table `specialitem`
--
ALTER TABLE `specialitem`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `item_id` (`item_id`,`date`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `availableitem`
--
ALTER TABLE `availableitem`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=615;

--
-- AUTO_INCREMENT for table `discountitem`
--
ALTER TABLE `discountitem`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `item`
--
ALTER TABLE `item`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `manager`
--
ALTER TABLE `manager`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `orderfromtablenumber`
--
ALTER TABLE `orderfromtablenumber`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `orderlist`
--
ALTER TABLE `orderlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `specialitem`
--
ALTER TABLE `specialitem`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `availableitem`
--
ALTER TABLE `availableitem`
  ADD CONSTRAINT `availableitem_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `item` (`id`);

--
-- Constraints for table `discountitem`
--
ALTER TABLE `discountitem`
  ADD CONSTRAINT `discountitem_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `item` (`id`);

--
-- Constraints for table `orderfromtablenumber`
--
ALTER TABLE `orderfromtablenumber`
  ADD CONSTRAINT `orderfromtablenumber_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `orderlist`
--
ALTER TABLE `orderlist`
  ADD CONSTRAINT `orderlist_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `orderlist_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `item` (`id`);

--
-- Constraints for table `specialitem`
--
ALTER TABLE `specialitem`
  ADD CONSTRAINT `specialitem_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `item` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
